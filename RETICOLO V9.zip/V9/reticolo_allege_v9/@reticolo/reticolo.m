function a=reticolo(a);
a=class(struct('ret',a),'reticolo');