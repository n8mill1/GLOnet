function display(a);
struct(getfield(struct(a),'ret'))