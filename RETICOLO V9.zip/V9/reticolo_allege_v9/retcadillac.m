function varargout=retcadillac(varargin);
% pour compatibilite avec une ancienne version avec une faute d'orthographe ... 
% See also: RETCADILHAC
[varargout{1:nargout}]=retcadilhac(varargin{:});
